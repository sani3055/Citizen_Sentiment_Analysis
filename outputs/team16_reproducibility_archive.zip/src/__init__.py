"""Core package initialization."""
